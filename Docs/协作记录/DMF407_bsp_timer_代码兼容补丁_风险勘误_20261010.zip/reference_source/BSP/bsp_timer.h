#ifndef BSP_TIMER_H
#define BSP_TIMER_H

#include <stdint.h>
#include "tim.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Phase 2: TIM2 and TIM4 timing only; no motor algorithm or pulse output.
 * TIM2: STM32F407 APB1 timer clock 84MHz, PSC=83, ARR=999 -> nominal 1ms.
 * TIM4: PSC=10, ARR=10000 -> ~1.31ms at 84MHz, NOT a 10ms timer.
 * TIM2 is a temporary PM1 timebase: PM2 encoder needs TIM2 CH1/CH2.
 */
HAL_StatusTypeDef BSP_Timer2_Start(void);
HAL_StatusTypeDef BSP_Timer4_Start(void);

/* Call once per corresponding HAL_TIM_PeriodElapsedCallback dispatch. */
void BSP_Timer_1msTick(void);
void BSP_Timer4_Tick(void);

/* Diagnostic event counters, NOT a validated absolute clock. */
uint32_t BSP_Timer_GetTim2Events(void);
uint32_t BSP_Timer_GetTim4Events(void);

/* Legacy main.c directly writes TIM4->ARR/CNT for the XY scheduler.
 * The motion layer must later consume these HAL wrappers rather than
 * directly editing timer registers. No step pulse is generated here.
 */
void BSP_Timer4_SetAutoReload(uint16_t arr);
uint16_t BSP_Timer4_GetAutoReload(void);
void BSP_Timer4_ResetCounter(void);
uint16_t BSP_Timer4_GetCounter(void);

#ifdef __cplusplus
}
#endif
#endif
