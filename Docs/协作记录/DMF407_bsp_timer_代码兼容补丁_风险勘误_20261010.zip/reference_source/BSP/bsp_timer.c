#include "bsp_timer.h"

static volatile uint32_t s_tim2_events;
static volatile uint32_t s_tim4_events;

HAL_StatusTypeDef BSP_Timer2_Start(void)
{
    /* Legacy time2.c:21,23,32: CNT=0, UIE enabled, counter started.
     * MX_TIM2_Init() must already have configured PSC=83 / ARR=999.
     */
    s_tim2_events = 0U;
    __HAL_TIM_SET_COUNTER(&htim2, 0U);
    /* An intentional defensive difference: ignore stale UIF on start. */
    __HAL_TIM_CLEAR_FLAG(&htim2, TIM_FLAG_UPDATE);
    return HAL_TIM_Base_Start_IT(&htim2);
}

HAL_StatusTypeDef BSP_Timer4_Start(void)
{
    /* Legacy time2.c:75,77,83: CNT=0, UIE enabled, counter started.
     * MX_TIM4_Init() must already have PSC=10 / ARR=10000.
     */
    s_tim4_events = 0U;
    __HAL_TIM_SET_COUNTER(&htim4, 0U);
    __HAL_TIM_CLEAR_FLAG(&htim4, TIM_FLAG_UPDATE);
    return HAL_TIM_Base_Start_IT(&htim4);
}

void BSP_Timer_1msTick(void)
{
    /* Diagnostic only. Legacy's calculate_motor_parameters() and its
     * theta/Speed_actual writes belong to the subsequent Control/Motor
     * integration. This is NOT yet a behavior-equivalent TIM2 ISR.
     */
    ++s_tim2_events;
}

void BSP_Timer4_Tick(void)
{
    /* Diagnostic only. Legacy clears motorX_pluse/motorY_pluse and bumps
     * motorX_position/motorY_position here. Motion is NOT yet migrated.
     */
    ++s_tim4_events;
}

uint32_t BSP_Timer_GetTim2Events(void)
{
    return s_tim2_events;
}

uint32_t BSP_Timer_GetTim4Events(void)
{
    return s_tim4_events;
}

void BSP_Timer4_SetAutoReload(uint16_t arr)
{
    __HAL_TIM_SET_AUTORELOAD(&htim4, (uint32_t)arr);
}

uint16_t BSP_Timer4_GetAutoReload(void)
{
    return (uint16_t)__HAL_TIM_GET_AUTORELOAD(&htim4);
}

void BSP_Timer4_ResetCounter(void)
{
    __HAL_TIM_SET_COUNTER(&htim4, 0U);
}

uint16_t BSP_Timer4_GetCounter(void)
{
    return (uint16_t)__HAL_TIM_GET_COUNTER(&htim4);
}
