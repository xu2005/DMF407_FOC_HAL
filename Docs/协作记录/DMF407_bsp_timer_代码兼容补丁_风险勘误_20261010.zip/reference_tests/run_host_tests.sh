#!/usr/bin/env bash
set -euo pipefail
project="$(cd "$(dirname "$0")/../.." && pwd)"
out="$(mktemp -d)"
trap 'rm -rf "$out"' EXIT
cc -std=c11 -Wall -Wextra -Werror -pedantic \
  -I"$project/tests/bsp_timer_mock/mock_hal" -I"$project/BSP" \
  "$project/BSP/bsp_timer.c" "$project/tests/bsp_timer_mock/test_bsp_timer.c" \
  -o "$out/test_bsp_timer"
"$out/test_bsp_timer"
