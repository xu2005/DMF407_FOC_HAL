#ifndef MOCK_TIM_H
#define MOCK_TIM_H
#include <stdint.h>
typedef enum { HAL_OK=0, HAL_ERROR=1 } HAL_StatusTypeDef;
typedef struct { uint32_t CNT, ARR, SR, DIER; } TIM_TypeDef;
typedef struct { TIM_TypeDef *Instance; } TIM_HandleTypeDef;
extern TIM_HandleTypeDef htim2, htim4;
extern uint8_t mock_fail_tim2, mock_fail_tim4;
extern unsigned mock_start_tim2, mock_start_tim4;
#define TIM_FLAG_UPDATE (1u << 0)
#define TIM_IT_UPDATE (1u << 0)
#define __HAL_TIM_SET_COUNTER(h,v) ((h)->Instance->CNT=(v))
#define __HAL_TIM_GET_COUNTER(h) ((h)->Instance->CNT)
#define __HAL_TIM_CLEAR_FLAG(h,v) ((h)->Instance->SR &= ~(v))
#define __HAL_TIM_SET_AUTORELOAD(h,v) ((h)->Instance->ARR=(v))
#define __HAL_TIM_GET_AUTORELOAD(h) ((h)->Instance->ARR)
HAL_StatusTypeDef HAL_TIM_Base_Start_IT(TIM_HandleTypeDef *h);
#endif
