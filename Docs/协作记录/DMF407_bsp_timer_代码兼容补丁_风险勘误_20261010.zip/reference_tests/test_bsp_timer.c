#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include "bsp_timer.h"

static TIM_TypeDef tim2_regs, tim4_regs;
TIM_HandleTypeDef htim2 = { &tim2_regs }, htim4 = { &tim4_regs };
uint8_t mock_fail_tim2, mock_fail_tim4;
unsigned mock_start_tim2, mock_start_tim4;

HAL_StatusTypeDef HAL_TIM_Base_Start_IT(TIM_HandleTypeDef *h)
{
    if (h == &htim2) {
        ++mock_start_tim2;
        if (mock_fail_tim2) return HAL_ERROR;
    } else if (h == &htim4) {
        ++mock_start_tim4;
        if (mock_fail_tim4) return HAL_ERROR;
    } else assert(0);
    h->Instance->DIER |= TIM_IT_UPDATE;
    return HAL_OK;
}

int main(void)
{
    tim2_regs.CNT=321; tim2_regs.SR=TIM_FLAG_UPDATE;
    tim4_regs.CNT=567; tim4_regs.SR=TIM_FLAG_UPDATE; tim4_regs.ARR=10000;
    assert(BSP_Timer2_Start()==HAL_OK);
    assert(BSP_Timer4_Start()==HAL_OK);
    assert(tim2_regs.CNT==0 && tim4_regs.CNT==0);
    assert(!(tim2_regs.SR&TIM_FLAG_UPDATE) && !(tim4_regs.SR&TIM_FLAG_UPDATE));
    assert(tim2_regs.DIER==TIM_IT_UPDATE && tim4_regs.DIER==TIM_IT_UPDATE);
    for(int i=0;i<7;i++) BSP_Timer_1msTick();
    for(int i=0;i<3;i++) BSP_Timer4_Tick();
    assert(BSP_Timer_GetTim2Events()==7 && BSP_Timer_GetTim4Events()==3);
    BSP_Timer4_SetAutoReload(4000);
    assert(BSP_Timer4_GetAutoReload()==4000);
    tim4_regs.CNT=100;
    assert(BSP_Timer4_GetCounter()==100);
    BSP_Timer4_ResetCounter();
    assert(BSP_Timer4_GetCounter()==0);
    mock_fail_tim2=1;
    assert(BSP_Timer2_Start()==HAL_ERROR);
    mock_fail_tim2=0;
    mock_fail_tim4=1;
    assert(BSP_Timer4_Start()==HAL_ERROR);
    puts("PASS: BSP timer host mock (start, UIF, counters, ARR, error propagation)");
    return 0;
}
