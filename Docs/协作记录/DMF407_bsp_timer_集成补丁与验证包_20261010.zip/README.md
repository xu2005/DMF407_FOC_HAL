# DMF407_FOC_HAL / bsp_timer integration package (2026-10-10)

Base: local ZIP's embedded Git commit b9731af995c2019f150bbf66d89f92e4cfe77468.
Scope: Phase 2 TIM2/TIM4 timing diagnostics; does not restore motor speed/angle update or TIM4 pulse/motion behaviour.

Contents:
- DMF407_bsp_timer_integration_b9731af.patch: unified patch for tracked files and newly created files.
- changed_files/: exact final file contents (reference, NOT a full source tree).
- SHA256SUMS.txt: patch digest.

Usage on Windows workstation (do not execute if baseline/diff differs):
  git rev-parse HEAD
  git status --short
  git apply --check DMF407_bsp_timer_integration_b9731af.patch
  git apply DMF407_bsp_timer_integration_b9731af.patch
  cmake --list-presets
  cmake --preset Debug
  cmake --build --preset Debug

No Git commit/push was performed here. On clean b9731af from uploaded ZIP the patch applies, and C11 host timer mock test passed.
Clang 17 Cortex-M4F targeted compile for three translation units passed, using HAL/CMSIS Drivers from uploaded complete ZIP, but GNU arm-none-eabi-gcc complete build was not run.

CRITICAL: Drivers/ is excluded from version control. New GitHub clones require matching STM32CubeF4 source generation/provisioning.
POWER-STAGE ENABLE BLOCKED remains in effect. Do not power the motor drive solely based on this software patch.
