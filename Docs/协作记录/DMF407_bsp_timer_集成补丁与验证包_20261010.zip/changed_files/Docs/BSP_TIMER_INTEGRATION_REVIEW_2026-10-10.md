# BSP TIM2/TIM4 integration review · 2026-10-10

## Provenance
This integration is derived from the user-uploaded `DMF407_FOC_HAL (2).zip`, whose embedded `main`/`origin/main` snapshots are both `b9731af`, and from the previously prepared `bsp_timer_agent_package_20261010.zip`. It was performed on an isolated extracted copy and **not on the user's Windows worktree or GitHub remote**. The uploaded archive contained 17 CRLF-only modified files (verified byte-identical after line-ending normalization); those changes were normalized in the isolated audit copy before generating this patch, to avoid irrelevant churn.

## Change scope
- Added BSP/bsp_timer.c/h with HAL TIM2/TIM4 start, event counters, TIM4 ARR/CNT interface.
- Added test harness `tests/bsp_timer_mock`.
- Added one source to CMakeLists.txt and one include to Core/Src/main.c.
- In Core/Src/main.c, preserve TIM3 encoder overflow callback and append TIM2/TIM4 diagnostics.
- Startup relative order: ADC -> TIM2 -> TIM4 -> Encoder -> TIM1, matching available Legacy behavior.
- Added D-13, D-14, D-15 to Docs/V1_Legacy_Mapping.md.

## Restrictions / NOT DONE
- TIM2 speed/angle update is NOT restored; Motor/Control consumes no timing event.
- TIM4 X/Y pulse flags, pulse acknowledgement, and positions are NOT restored; Motion consumes no timing event.
- The TIM1 FOC interrupt is not mapped to live FOC; power-stage enable remains BLOCKED.
- No actual board measurements, exact ISR execution frequency, electrical safety verification, or GitHub push was carried out by this integration package.
- ARM GCC not installed in current container: no real `arm-none-eabi-gcc` link/build result. Host test and Clang ARM-target syntax validation, if available, are not substitutes for the project's GNU Arm cross-link/build.
- TIM2 is temporary and will conflict with the PM2 encoder in true dual-axis mode.

## Before merging in Windows Codex
1. Commit/stash any real local work, do not discard user changes without review.
2. Verify source commit and compare expected logical diff. Do not overwrite generated files from a stale snapshot.
3. Apply patch via `git apply --check`, then `git apply` against exact b9731af state or manually merge the corresponding edits.
4. `cmake --list-presets; cmake --preset Debug; cmake --build --preset Debug` and verify .elf/.map/.bin/.hex and symbols.
5. Keep motor power DC disconnected. Confirm MCU-only TIM2/TIM3/TIM4 interrupt rates on board before accepting hardware behavior.
6. Commit/push only from user's authorized local environment, verify `git status` and `git ls-remote` before claiming cloud sync.

## Checks completed in the isolated container
- `git apply --check` and `git apply` succeeded on a separate clean checkout of embedded commit `b9731af`.
- Host C11 `tests/bsp_timer_mock/run_host_tests.sh`: PASS.
- Clang 17 ARM Cortex-M4F targeted object compilation: PASS for `BSP/bsp_timer.c`, `Core/Src/main.c`, `Core/Src/stm32f4xx_it.c`, creating ARM EABI5 relocatable objects.
- `git diff --check`: PASS.
- **No GNU Arm linking was performed**: this container lacks `arm-none-eabi-gcc`, and these ARM object builds do not establish a complete ELF/MAP/BIN build.
- Fresh repository checkout did not contain `Drivers/` (ignored by Git). Clang test resolved the absent HAL/CMSIS includes by linking the Drivers tree from the user-uploaded complete ZIP. Thus a fresh cloud clone is not yet independently buildable without obtaining the matching STM32CubeF4 package.

## Important source note
- The generated `Core/Src/main.c` currently uses RCC PLLQ=4, whereas an older checklist text mentions PLLQ=7. This task did **not** change PLLQ; before using USB or 48-MHz peripherals, compare the actual `.ioc` against the official clock tree.
